import {Component} from "@angular/core";
import {ICellRendererAngularComp} from "ag-grid-angular";

@Component({
    selector: 'child-cell',
    template: `<span><mat-icon style="font-size: 18px" color="primary" *ngIf="params.context.componentParent.access.editAccess==1" (click)="edit()">edit</mat-icon> &nbsp; <mat-icon style="font-size: 18px" color="primary" *ngIf="params.context.componentParent.access.viewAccess==1" (click)="view()">visibility</mat-icon></span>`,
    styles: [
        `.btn {
            line-height: 0.5
        }`
    ]
})
export class ChildMessageRenderer implements ICellRendererAngularComp {
    public params: any;

    agInit(params: any): void {
        this.params = params;
        console.log(params.context);
    }

    public edit() {
        this.params.context.componentParent.methodFromParentEdit(`Row: ${this.params.node.rowIndex}, Col: ${this.params.colDef.headerName}`,this.params.data)
    }

    public view() {
        this.params.context.componentParent.methodFromParentView(`Row: ${this.params.node.rowIndex}, Col: ${this.params.colDef.headerName}`,this.params.data)
    }

    refresh(): boolean {
        return false;
    }
}