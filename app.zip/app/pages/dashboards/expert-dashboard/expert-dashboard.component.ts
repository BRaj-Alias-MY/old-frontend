import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-expert-dashboard',
  templateUrl: './expert-dashboard.component.html',
  styleUrls: ['./expert-dashboard.component.css']
})
export class ExpertDashboardComponent implements OnInit {
  dasboardData: any;

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
         
             gridLines: {
                offsetGridLines: true
          }
      }]
    }
  };
  public barChartLabels:any;
  public barChartType = 'bar';
  public barChartLegend = true;
  public barChartData:any;
  
  constructor(private api: ApiService) {
    this.barChartLabels = [];
    this.barChartData = [
      {data: [], label: 'Monthly Data'}
    ];
   }
  ngOnInit() {
    this.api.expertdashboard().subscribe(data=>{
      this.dasboardData = data.data;
    
      for(let i=0;i< this.dasboardData.monthlydata.length;i++){
        this.barChartLabels.push(this.dasboardData.monthlydata[i].month);
        this.barChartData[0].data.push(Number(this.dasboardData.monthlydata[i].cnt));
      }
    });
  }

}