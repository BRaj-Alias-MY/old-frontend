import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../../services/api.service';


@Injectable({
  providedIn: 'root'
})
export class PaymentsService {

  constructor(private main_api: ApiService, private http: HttpClient) { }

  generate_coupons(data) {
		return this.http.post<any>(this.main_api.get_base() + 'coupons/generate', data);
	}

   createinterview(data){
	return this.http.post<any>(this.main_api.get_base() + 'interview/create', data);
   }
	
   getinterviews(){
	return this.http.get<any>(this.main_api.get_base()+'interview/interview-list');
	}
	
	get_domain(){
		return this.http.get<any>(this.main_api.get_base()+'domain/list');
	}
	get_subdomain(id){
		return this.http.get<any>(this.main_api.get_base()+'domain/list/' + id);
   }

   get_explevel(){
	  return this.http.get<any>(this.main_api.get_base()+"exp-level/list");
	}
	
   getquestion(id1,id2){
	return this.http.get<any>(this.main_api.get_base() + 'questions/list/' +id1 +'/'+id2 );
   }

	save_chequedetails(data)
	{
		return this.http.post<any>(this.main_api.get_base() + 'payments/checkDetails/'+data.id, data);
    }
	get_coupons() {
		return this.http.get<any>(this.main_api.get_base() + 'coupons/');
  }
  coupons_update(data){
		return this.http.post<any>(this.main_api.get_base()+"exp-level/"+data.id, data);
	 }
	 get_organization(){
		return this.http.get<any>(this.main_api.get_base()+'organization/list');
	}
	get_interviewtypes(){
		return this.http.get<any>(this.main_api.get_base()+'interviewtype/list');
	} 

	get_interviewids(){
		return this.http.get<any>(this.main_api.get_base()+'interview/interview-list');
      }
	get_discountval(data){
		return this.http.get<any>(this.main_api.get_base()+'coupons/validate/'+data);
	 }
	 
	 savepayment(data){
		return this.http.post<any>(this.main_api.get_base()+"payments/orgPaymentMap", data);
	}

	saveinterview(data){
		return this.http.post<any>(this.main_api.get_base()+"interview/map-groups", data);

	}
	

	get_user_groups(){
		return this.http.get<any>(this.main_api.get_base()+'usergroup/list');
	  }
	  
	get_amount(id){
		return this.http.get<any>(this.main_api.get_base()+'payments/validateorg/'+id);
       }
	
    save_info(data,id){
		return this.http.post<any>(this.main_api.get_base()+"payments/postpayment/"+id, data);

	}

	get_cheque_details(){
		return this.http.get<any>(this.main_api.get_base()+'payments/checkDetails');

	}

	
}
