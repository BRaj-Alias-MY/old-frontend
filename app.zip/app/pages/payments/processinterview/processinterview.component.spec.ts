import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessinterviewComponent } from './processinterview.component';

describe('ProcessinterviewComponent', () => {
  let component: ProcessinterviewComponent;
  let fixture: ComponentFixture<ProcessinterviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProcessinterviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessinterviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
