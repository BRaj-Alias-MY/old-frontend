import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";

@Component({
  selector: "app-testmysetup2",
  templateUrl: "./testmysetup2.component.html",
  styleUrls: ["./testmysetup2.component.css"]
})
export class Testmysetup2Component implements OnInit {
  @ViewChild("video")
  public video: ElementRef;
  @ViewChild("audio")
  public audio: ElementRef;

  selectedVideoDevice: string;
  selectedAudioDevice: string;
  selectedBrowser: string;
  selectedOs: string;
  showText: boolean;
  videos: boolean;
  browser: string;
  os: string;
  audios: boolean;
  showError: boolean;
  canJoinMeeting: boolean;
  browserstatus: boolean;
  osstatus: boolean;
  canStopTest: boolean;
  errorMessage: string;

  availableVideoDevices: Array<{ deviceId: string; name: string }>;
  availableAudioDevices: Array<{ deviceId: string; name: string }>;
  availableBrowsers: Array<{ deviceId: string; name: string }>;

  public ngOnInit() {
    this.showText = false;
    this.showError = false;
    this.canStopTest = false;
    this.canJoinMeeting = true;
    this.browserstatus = false;
    this.osstatus = false;
    this.videos = false;
    this.audios = false;
    this.availableVideoDevices = [];
    this.availableAudioDevices = [];
    this.availableBrowsers = [];
    this.selectedBrowser = undefined;
    this.selectedVideoDevice = undefined;
    this.selectedAudioDevice = undefined;
    this.browser = undefined;
    this.browserstatus = undefined;
    this.osstatus = undefined;
    this.os = undefined;
    this.detectDevices();
  }
  private detectVideo() {
    navigator.mediaDevices
      .enumerateDevices()
      .then(devices => {
        devices.forEach(device => {
          if (device.kind === "videoinput") {
            if (!this.selectedVideoDevice) {
              this.selectedVideoDevice = device.deviceId;
            }
            this.videos = true;
            this.availableVideoDevices.push({
              deviceId: device.deviceId,
              name:
                device.label ||
                `camera ${this.availableVideoDevices.length + 1}`
            });
          }
        });
      })
      .catch(error => this.handleError(error));
  }
  private detectAudio() {
    navigator.mediaDevices
      .enumerateDevices()
      .then(devices => {
        devices.forEach(device => {
          if (device.kind === "audioinput") {
            if (!this.selectedAudioDevice) {
              this.selectedAudioDevice = device.deviceId;
            }
            this.audios = true;
            this.availableAudioDevices.push({
              deviceId: device.deviceId,
              name:
                device.label ||
                `microphone ${this.availableAudioDevices.length + 1}`
            });
          }
        });
      })
      .catch(error => this.handleError(error));
  }
  private detectDevices() {
    navigator.mediaDevices
      .enumerateDevices()
      .then(devices => {
        devices.forEach(device => {
          this.selectedBrowser = navigator.vendor;
          if (navigator.vendor) {
            this.browser = window.navigator.vendor;
            this.browserstatus = true;
          }
          this.selectedBrowser = navigator.platform;
          if (navigator.platform) {
            this.os = window.navigator.platform;
            this.osstatus = true;
          }
        });
      })
      .catch(error => this.handleError(error));
  }

  ondetect() {
    this.onStart();
  }
  onStart() {
    this.startAudio();
    this.startVideo();
    this.detectAudio();
    this.detectDevices();
    this.detectVideo();
    this.detectDevices();
    this.canStopTest = true;
  }
  onstop() {
    this.stopTest();
  }
  onVideoDeviceChange(videoDevice) {
    this.selectedVideoDevice = videoDevice;
    this.canJoinMeeting = true;
  }
  onAudioDeviceChange(audioDevice) {
    this.selectedAudioDevice = audioDevice;
    this.canJoinMeeting = true;
  }
  startVideo() {
    this.showError = true;
    const audioSource = this.selectedAudioDevice;
    const videoSource = this.selectedVideoDevice;
    const browserSource = this.selectedBrowser;
    const constraints = {
      audio: { deviceId: audioSource ? { exact: audioSource } : undefined },
      video: { deviceId: videoSource ? { exact: videoSource } : undefined },
      browser: {
        deviceId: browserSource ? { exact: browserSource } : undefined
      }
    };
    if (
      navigator.mediaDevices &&
      navigator.mediaDevices.getUserMedia &&
      navigator.onLine &&
      navigator.userAgent
    ) {
      navigator.mediaDevices
        .getUserMedia(constraints)
        .then(stream => {
          this.video.nativeElement.srcObject = stream;
          this.video.nativeElement.muted = true;
          this.video.nativeElement.play();
          this.showText = false;
          this.videos = true;
          this.canJoinMeeting = true;
          this.canStopTest = true;
        })
        .catch(error => this.handleError(error));
    } else {
      this.canStopTest = false;
      alert(
        "Something went wrong!Your Equipment is not Working Properly You Cannot Go To Take Interview"
      );
    }
  }
  startAudio() {
    this.showError = true;
    const audioSource = this.selectedAudioDevice;
    //const videoSource = this.selectedVideoDevice;
    const browserSource = this.selectedBrowser;
    const constraints = {
      audio: { deviceId: audioSource ? { exact: audioSource } : undefined },
      //video: { deviceId: videoSource ? { exact: videoSource } : undefined },
      browser: {
        deviceId: browserSource ? { exact: browserSource } : undefined
      }
    };
    if (
      navigator.mediaDevices &&
      navigator.mediaDevices.getUserMedia &&
      navigator.onLine &&
      navigator.userAgent
    ) {
      navigator.mediaDevices
        .getUserMedia(constraints)
        .then(stream => {
          this.audio.nativeElement.srcObject = stream;
          //this.audio.nativeElement.muted = false;
          //this.audio.nativeElement.play();
          this.showText = false;
          this.canJoinMeeting = true;
          this.audios = true;
          this.canStopTest = true;
        })
        .catch(error => this.handleError(error));
    } else {
      this.canStopTest = false;
      alert(
        "Something went wrong!Your Equipment is not Working Properly You Cannot Go To Take Interview"
      );
    }
  }
  // startTest() {
  //   this.showError = false;
  //   const audioSource = this.selectedAudioDevice;
  //   const videoSource = this.selectedVideoDevice;
  //   const browserSource = this.selectedBrowser;
  //   const constraints = {
  //     audio: { deviceId: audioSource ? { exact: audioSource } : undefined },
  //     video: { deviceId: videoSource ? { exact: videoSource } : undefined },
  //     browser: { deviceId: browserSource ? { exact: browserSource } : undefined }
  //   };
  //   if (
  //     navigator.mediaDevices &&
  //     navigator.mediaDevices.getUserMedia &&
  //     navigator.userAgent
  //   ) {
  //     navigator.mediaDevices
  //       .getUserMedia(constraints)
  //       .then(stream => {
  //         this.video.nativeElement.srcObject = stream;
  //         this.video.nativeElement.muted = true;
  //         this.video.nativeElement.play();
  //         this.audio.nativeElement.play();
  //         const audioContext = new AudioContext();
  //         const analyser = audioContext.createAnalyser();
  //         //const microphone = audioContext.createMediaStreamSource(stream);
  //         const javascriptNode = audioContext.createScriptProcessor(2048, 1, 1);

  //         analyser.smoothingTimeConstant = 0.8;
  //         analyser.fftSize = 1024;

  //         this.audio.nativeElement.connect(analyser);
  //         analyser.connect(javascriptNode);
  //         javascriptNode.connect(audioContext.destination);
  //         javascriptNode.onaudioprocess = function() {
  //           const array = new Uint8Array(analyser.frequencyBinCount);
  //           analyser.getByteFrequencyData(array);
  //           let values = 0;

  //           const length = array.length;
  //           for (let i = 0; i < length; i++) {
  //             values += array[i];
  //           }

  //           const average = values / length;

  //           console.log(Math.round(average));
  //           //colorPids(average);
  //           const all_pids = $(".pid");
  //           const amout_of_pids = Math.round(average / 10);
  //           const elem_range = all_pids.slice(0, amout_of_pids);
  //           for (let i = 0; i < all_pids.length; i++) {
  //             all_pids[i].style.backgroundColor = "#e6e7e8";
  //           }
  //           for (let i = 0; i < elem_range.length; i++) {
  //             console.log(elem_range[i]);
  //             elem_range[i].style.backgroundColor = "#69ce2b";
  //           }
  //           // canvasContext.clearRect(0, 0, 150, 300);
  //           // canvasContext.fillStyle = "#BadA55";
  //           // canvasContext.fillRect(0, 300 - average, 150, 150);
  //           // canvasContext.fillStyle = "#262626";
  //           // canvasContext.font = "48px impact";
  //           // canvasContext.fillText(Math.round(average - 40), -2, 300);
  //         };
  //         this.showText = true;
  //         this.canJoinMeeting = false;
  //         this.canStopTest = true;
  //       })
  //       .catch(error => this.handleError(error));
  //   } else {
  //     this.canStopTest = false;
  //     alert("Please check your equipment if Working Properly");
  //   }
  // }

  stopTest() {
    this.showError = false;
    // const stream = this.video.nativeElement.srcObject;
    // const tracks = stream.getTracks();
    // tracks.forEach(function (track) {
    //   track.stop();
    // })
    this.video.nativeElement.srcObject = null;
    this.showText = true;
    this.canJoinMeeting = false;
    this.canStopTest = false;
    alert("If You Can See Yourself Your Equipment is Working Sucessfully");
  }

  private handleError(error) {
    this.showError = true;
    this.errorMessage = error.toString();
  }
}
