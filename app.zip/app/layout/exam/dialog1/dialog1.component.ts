import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { MatDialogRef } from "@angular/material";
import { Entrypage2Component } from '../entrypage2/entrypage2.component';
@Component({
  selector: 'app-dialog1',
  templateUrl: './dialog1.component.html',
  styleUrls: ['./dialog1.component.css']
})
export class Dialog1Component implements OnInit {

  constructor(
    private router: Router,
    public dialogRef: MatDialogRef<Entrypage2Component>) { }

  ngOnInit() {
  }
  close() {
    this.dialogRef.close("Thanks for using me!");
  }
  success() {
    this.router.navigate(['/examboard2/testsetup2']);
    this.dialogRef.close("Thanks for using me!");
  }

}
