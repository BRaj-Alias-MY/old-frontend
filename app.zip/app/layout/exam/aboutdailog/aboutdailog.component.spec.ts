import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutdailogComponent } from './aboutdailog.component';

describe('AboutdailogComponent', () => {
  let component: AboutdailogComponent;
  let fixture: ComponentFixture<AboutdailogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutdailogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutdailogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
