import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExperiancedialogComponent } from './experiancedialog.component';

describe('ExperiancedialogComponent', () => {
  let component: ExperiancedialogComponent;
  let fixture: ComponentFixture<ExperiancedialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExperiancedialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExperiancedialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
